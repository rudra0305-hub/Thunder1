# Thunder Chat Android wrapper

This project packages the deployed Thunder Chat website in a simple Android WebView APK.

Live website: https://thunder-chat-0zqcrh.v2.appdeploy.ai/

## Build an APK without installing Android Studio

1. Download and extract this ZIP.
2. Create a new GitHub repository at https://github.com/new.
3. Upload **all extracted files and folders** to the repository root. Make sure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab and select **Build Thunder Chat APK**.
5. Tap **Run workflow** if the workflow has not already started.
6. Open the completed run and download the `thunder-chat-debug-apk` artifact.
7. Extract the artifact ZIP to get `app-debug.apk`.

The workflow creates a debug APK for testing/sideloading. It is not a signed release APK for Google Play. This ZIP is source code; it does not contain a precompiled APK.

## Current app features

- Sign-in, member profiles, private chats, groups, and live text messages.
- Photo/file attachments up to 3 MB (supported image, video, audio, PDF and plain-text types).
- Voice-note recording and audio playback in supported browsers.
- Push-notification delivery is attempted for other members; actual delivery depends on platform/device notification support and permission.

## Important limitations

- This is a WebView wrapper, not a fully native rewrite. It needs an internet connection because it loads the hosted website.
- Voice/video calling, true online/last-seen presence, and end-to-end encryption are not implemented yet. Do not treat this beta as a fully secure replacement for established messengers.
- Authentication providers sometimes restrict sign-in inside embedded WebViews. If sign-in does not work reliably in the wrapper, use Chrome on Android and choose **Install app / Add to Home screen** on the live website; that PWA route often works better for web authentication.
- Before sharing widely, test sign-in, messages, attachments, microphone permission, and notification delivery on the target devices.
